import glob
import os
import sys

YOL = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, YOL)

from cetvel import cetvel_parse
from efatura import efatura_parse
from matcher import capraz_kontrol
from utils import tl_format

TEST_KLASORU = os.path.join(YOL, "test_veri")

BASARILI = True


def kontrol(ad, kosul, detay=""):
    global BASARILI
    durum = "TAMAM" if kosul else "HATA"
    if not kosul:
        BASARILI = False
    print(f"  [{durum}] {ad} {detay}")


if __name__ == "__main__":
    fatura_dosyalari = sorted(glob.glob(os.path.join(TEST_KLASORU, "fatura_*.pdf")))
    cetvel_dosyalari = glob.glob(os.path.join(TEST_KLASORU, "kontrol_cetveli.pdf"))

    print("== TOPLU FATURA (çok sayfalı) ==")
    toplu_faturalar = efatura_parse(os.path.join(TEST_KLASORU, "Toplu Fatura Yazdırma.pdf"))
    for f in toplu_faturalar:
        print(f"  sayfa={f['sayfa']} belge={f['belge_no']} matrah={tl_format(f['matrah'])} kdv={tl_format(f['kdv'])} toplam={tl_format(f['toplam'])}")
    kontrol("toplu 2 fatura", len(toplu_faturalar) == 2, f"-> {len(toplu_faturalar)}")
    kontrol("toplu sayfa 1", toplu_faturalar[0]["belge_no"] == "GFE202400000011")
    kontrol("toplu sayfa 2", toplu_faturalar[1]["belge_no"] == "GFE202400000012")
    kontrol("toplu kdv 1", toplu_faturalar[0]["kdv"] == 200)
    kontrol("toplu tutar tutarli", not any(n for n in toplu_faturalar[0]["notlar"] if "≠" in n))

    print("\n== TARANMIŞ CETVEL (OCR) ==")
    from cetvel import cetvel_parse
    tarama_sonuc = cetvel_parse(os.path.join(TEST_KLASORU, "taranmis_cetvel.pdf"))
    print("  notlar:", tarama_sonuc["notlar"])
    for c in tarama_sonuc["kayitlar"][:8]:
        print(f"  vkn={c['vkn']} belge={c['belge_no']} tarih={c['tarih']} matrah={tl_format(c['matrah'])} kdv={tl_format(c['kdv'])}")
    kontrol("tarama kayit sayisi", len(tarama_sonuc["kayitlar"]) >= 5, f"-> {len(tarama_sonuc['kayitlar'])}")
    ilk = tarama_sonuc["kayitlar"][0]
    kontrol("tarama ilk vkn", ilk["vkn"] == "12345678901", f"-> {ilk['vkn']}")
    kontrol("tarama ilk kdv", ilk["kdv"] == 200, f"-> {ilk['kdv']}")

    print("\n== EXCEL FATURA LİSTESİ ==")
    from dosya import cetvel_dosya_parse, fatura_dosya_parse
    excel_faturalar = fatura_dosya_parse(os.path.join(TEST_KLASORU, "fatura_listesi.xlsx"))
    for f in excel_faturalar:
        print(f"  satir={f['satir']} belge={f['belge_no']} vkn={f['satici_vkn']} matrah={tl_format(f['matrah'])} kdv={tl_format(f['kdv'])} toplam={tl_format(f['toplam'])}")
    kontrol("excel fatura 4 kayit", len(excel_faturalar) == 4, f"-> {len(excel_faturalar)}")
    kontrol("excel fatura 1", excel_faturalar[0]["belge_no"] == "GFE202400000001" and excel_faturalar[0]["matrah"] == 1000)
    kontrol("excel fatura kdv", excel_faturalar[2]["kdv"] == 50)

    print("\n== EXCEL CETVEL LİSTESİ ==")
    excel_cetvel = cetvel_dosya_parse(os.path.join(TEST_KLASORU, "kontrol_cetveli.xlsx"))
    print("  notlar:", excel_cetvel["notlar"])
    for c in excel_cetvel["kayitlar"]:
        print(f"  vkn={c['vkn']} belge={c['belge_no']} tarih={c['tarih']} matrah={tl_format(c['matrah'])} kdv={tl_format(c['kdv'])}")
    kontrol("excel cetvel 4 kayit", len(excel_cetvel["kayitlar"]) == 4, f"-> {len(excel_cetvel['kayitlar'])}")
    kontrol("excel cetvel kdv", excel_cetvel["kayitlar"][2]["kdv"] == 45)
    kontrol("excel cetvel toplam satiri atlandi", not any(c["belge_no"] == "GENELTOPLAM" for c in excel_cetvel["kayitlar"]))

    print("\n== XML FATURA (UBL e-fatura) ==")
    from dosya import fatura_dosya_parse as fatura_dosya_parse_fn
    from xml_oku import fatura_xml_parse
    xml_faturalar = []
    for d in sorted(glob.glob(os.path.join(TEST_KLASORU, "fatura_*.xml"))):
        xml_faturalar.extend(fatura_xml_parse(d))
    for f in xml_faturalar:
        print(f"  {os.path.basename(f['dosya'])}: belge={f['belge_no']} tarih={f['tarih']} "
              f"satici={f['satici_vkn']} matrah={tl_format(f['matrah'])} kdv={tl_format(f['kdv'])} toplam={tl_format(f['toplam'])} oran={f['oranlar']}")
    kontrol("xml 5 fatura", len(xml_faturalar) == 5, f"-> {len(xml_faturalar)}")
    kontrol("xml 1 belge", xml_faturalar[0]["belge_no"] == "GFE202400000001")
    kontrol("xml 1 vkn", xml_faturalar[0]["satici_vkn"] == "12345678901")
    kontrol("xml 1 matrah", xml_faturalar[0]["matrah"] == 1000)
    kontrol("xml 1 kdv", xml_faturalar[0]["kdv"] == 200)
    kontrol("xml 1 toplam", xml_faturalar[0]["toplam"] == 1200)
    kontrol("xml 3 kdv", xml_faturalar[2]["kdv"] == 50)
    kontrol("xml 3 oran", 10 in xml_faturalar[2]["oranlar"])
    kontrol("xml 5 vkn", xml_faturalar[4]["satici_vkn"] == "00099988877")
    gz = fatura_xml_parse(os.path.join(TEST_KLASORU, "sikistirilmis_fatura.xml"))
    kontrol("xml gzip acildi", len(gz) == 1 and gz[0]["belge_no"] == "GFE202400000099" and gz[0]["kdv"] == 90, f"-> {gz[0]['belge_no'] if gz else None}")
    xml_dosya_parse = fatura_dosya_parse_fn(os.path.join(TEST_KLASORU, "fatura_1.xml"))
    kontrol("xml dosya yonlendirme", len(xml_dosya_parse) == 1 and xml_dosya_parse[0]["belge_no"] == "GFE202400000001")

    print("\n== XML TİP / VERGİ DETAYI / ORAN KONTROL ==")
    kontrol("xml 1 tip satis", xml_faturalar[0]["fatura_tipi"] == "SATIS", f"-> {xml_faturalar[0]['fatura_tipi']}")
    kontrol("xml 1 vergi detayi var", len(xml_faturalar[0]["vergi_detay"]) >= 1, f"-> {len(xml_faturalar[0]['vergi_detay'])}")
    ilk_detay = xml_faturalar[0]["vergi_detay"][0]
    kontrol("xml 1 detay oran", ilk_detay["oran"] == 20, f"-> {ilk_detay.get('oran')}")
    kontrol("xml 1 detay matrah", ilk_detay["matrah"] == 1000, f"-> {ilk_detay.get('matrah')}")
    kontrol("xml 1 detay kdv", ilk_detay["kdv"] == 200, f"-> {ilk_detay.get('kdv')}")
    kontrol("xml 1 oran kontrol ok", xml_faturalar[0]["oran_kontrol"] == "OK", f"-> {xml_faturalar[0]['oran_kontrol']}")
    kontrol("xml 1 oran notu yok", not any("Matrah×Oran" in n for n in xml_faturalar[0]["notlar"]))
    kontrol("xml 3 oran kontrol", xml_faturalar[2]["oran_kontrol"] in ("OK", ""), f"-> {xml_faturalar[2]['oran_kontrol']}")

    print("\n== İADE FATURA EŞLEŞMESİ ==")
    from decimal import Decimal
    iade_f = [{
        "belge_no": "IADE202400000001", "tarih": "2024-02-10",
        "satici_vkn": "12345678901", "satici_unvan": "Test Satıcı",
        "matrah": Decimal("-1000.00"), "kdv": Decimal("-200.00"),
        "toplam": Decimal("-1200.00"), "oranlar": [20], "fatura_tipi": "IADE",
        "oran_kontrol": "OK", "notlar": [], "dosya": "iade.xml", "tip": "xml",
    }]
    iade_c = [{
        "belge_no": "IADE202400000001", "tarih": "2024-02-10",
        "vkn": "12345678901", "unvan": "Test Satıcı",
        "matrah": None, "kdv": Decimal("200.00"), "notlar": [],
    }]
    from matcher import capraz_kontrol_iade_destekli
    i_sonuc, i_ozet = capraz_kontrol_iade_destekli(iade_f, iade_c)
    kontrol("iade eslesen durum", i_sonuc[0]["durum"] == "İADE EŞLEŞTİ", f"-> {i_sonuc[0]['durum']}")
    kontrol("iade kdv abs", i_sonuc[0]["kdv"] == 200, f"-> {i_sonuc[0]['kdv']}")
    kontrol("iade tip tasindi", i_sonuc[0]["tip"] == "IADE", f"-> {i_sonuc[0]['tip']}")
    kontrol("iade oran kontrol", i_sonuc[0]["oran_kontrol"] == "OK", f"-> {i_sonuc[0]['oran_kontrol']}")
    kontrol("iade ozet", i_ozet["iade_adet"] == 1 and i_ozet["fatura_adet"] == 1, f"-> {i_ozet}")

    print("\n== FATURA PARSE ==")
    faturalar = []
    for d in fatura_dosyalari:
        faturalar.extend(efatura_parse(d))
    for f in faturalar:
        print(f"  {os.path.basename(f['dosya'])}: belge={f['belge_no']} tarih={f['tarih']} "
              f"satici={f['satici_vkn']} matrah={tl_format(f['matrah'])} kdv={tl_format(f['kdv'])} toplam={tl_format(f['toplam'])}")

    kontrol("1 no okundu", faturalar[0]["belge_no"] == "GFE202400000001")
    kontrol("1 tarih", faturalar[0]["tarih"] == "2024-02-05")
    kontrol("1 satıcı VKN", faturalar[0]["satici_vkn"] == "12345678901")
    kontrol("1 matrah", faturalar[0]["matrah"] == 1000)
    kontrol("1 kdv", faturalar[0]["kdv"] == 200)
    kontrol("1 toplam", faturalar[0]["toplam"] == 1200)
    kontrol("3 kdv %10", faturalar[2]["kdv"] == 50)
    kontrol("5 vkn", faturalar[4]["satici_vkn"] == "00099988877")

    print("\n== CETVEL PARSE ==")
    cetvel_sonuc = cetvel_parse(cetvel_dosyalari[0])
    for c in cetvel_sonuc["kayitlar"]:
        print(f"  vkn={c['vkn']} belge={c['belge_no']} tarih={c['tarih']} "
              f"matrah={tl_format(c['matrah'])} kdv={tl_format(c['kdv'])} unvan={c['unvan']}")
    kontrol("cetvel 6 kayit", len(cetvel_sonuc["kayitlar"]) == 6, f"-> {len(cetvel_sonuc['kayitlar'])}")
    kontrol("cetvel 1 belge no", cetvel_sonuc["kayitlar"][0]["belge_no"] == "GFE202400000001")
    kontrol("cetvel 1 kdv", cetvel_sonuc["kayitlar"][0]["kdv"] == 200)
    kontrol("cetvel 3 kdv 45", cetvel_sonuc["kayitlar"][2]["kdv"] == 45)
    kontrol("cetvel 4 belge", cetvel_sonuc["kayitlar"][3]["belge_no"] == "GFE202400000009")
    kontrol("cetvel 6 vkn", cetvel_sonuc["kayitlar"][5]["vkn"] == "11122233344")

    print("\n== ÇAPRAZ KONTROL ==")
    sonuclar, ozet = capraz_kontrol(faturalar, cetvel_sonuc["kayitlar"])
    for s in sonuclar:
        print(f"  [{s['durum']}] {s['belge_no'] or ''} vkn={s['vkn'] or ''} "
              f"matrah={tl_format(s['matrah'])} kdv={tl_format(s['kdv'])} {s['detay']}")
    print("  OZET:", ozet)

    kontrol("eslesen 2", ozet["eslesen"] == 2, f"-> {ozet['eslesen']}")
    kontrol("tutar farki 1", ozet["tutar_farki"] == 1, f"-> {ozet['tutar_farki']}")
    kontrol("vkn farki 1", ozet["vkn_farki"] == 1, f"-> {ozet['vkn_farki']}")
    kontrol("cetvelde yok 1", ozet["cetvelde_yok"] == 1, f"-> {ozet['cetvelde_yok']}")
    kontrol("faturada yok 1", ozet["faturada_yok"] == 1, f"-> {ozet['faturada_yok']}")
    kontrol("mukerrer 1", ozet["mukerrer"] == 1, f"-> {ozet['mukerrer']}")

    print("\n== KARIŞIK ÇAPRAZ KONTROL (PDF + Excel) ==")
    karisik_faturalar = list(faturalar) + excel_faturalar
    karisik_cetvel = cetvel_sonuc["kayitlar"] + excel_cetvel["kayitlar"]
    k_sonuc, k_ozet = capraz_kontrol(karisik_faturalar, karisik_cetvel)
    for s in k_sonuc:
        print(f"  [{s['durum']}] {s['belge_no'] or ''} vkn={s['vkn'] or ''} {s['detay']}")
    print("  OZET:", k_ozet)
    kontrol("karisik eslesen 4", k_ozet["eslesen"] == 4, f"-> {k_ozet['eslesen']}")
    kontrol("karisik tutar farki 2", k_ozet["tutar_farki"] == 2, f"-> {k_ozet['tutar_farki']}")

    print("\n== ÖZETLER (KDV DAĞILIMI / BA FORMU / EKSİK BELGELER) ==")
    from ozetler import ba_formu, eksik_belgeler, kdv_dagilim_fatura, kdv_dagilim_muavin
    fatura_dag = kdv_dagilim_fatura(xml_faturalar)
    kontrol("fatura dagilim %20 var", 20 in fatura_dag, f"-> {fatura_dag.get(20)}")
    kontrol("fatura dagilim %20 adet", fatura_dag[20]["adet"] == 3 and fatura_dag[20]["kdv"] == 860,
            f"-> {fatura_dag.get(20)}")
    kontrol("fatura dagilim %10 var", 10 in fatura_dag, f"-> {fatura_dag.get(10)}")
    muavin_dag = kdv_dagilim_muavin(cetvel_sonuc["kayitlar"])
    kontrol("muavin dagilim kayitli", sum(g["adet"] for g in muavin_dag.values()) == len(cetvel_sonuc["kayitlar"]),
            f"-> {len(cetvel_sonuc['kayitlar'])}")
    ba = ba_formu(xml_faturalar)
    kontrol("ba formu saticilar", len(ba) >= 3, f"-> {len(ba)}")
    kontrol("ba formu adet toplami", sum(s["adet"] for s in ba) == len(xml_faturalar))
    eksikler = eksik_belgeler(sonuclar)
    kontrol("eksik belgeler", eksikler == ["GFE202400000004"], f"-> {eksikler}")

    print("\n== GEÇMİŞ KARŞILAŞTIRMA (config) ==")
    import config
    import tempfile
    config.GECMIS_YOLU = os.path.join(tempfile.gettempdir(), "kdv_test_gecmis.json")
    if os.path.exists(config.GECMIS_YOLU):
        os.remove(config.GECMIS_YOLU)
    kontrol("gecmis bos", config.gecmis_karsilastir(eksikler) is None)
    config.gecmis_ekle(ozet, ["GFE202400000005", "GFE202400000006"])
    gecmis = config.gecmis_karsilastir(["GFE202400000005"])
    kontrol("gecmis kapanan", gecmis is not None and gecmis["kapanan"] == ["GFE202400000006"], f"-> {gecmis}")
    kontrol("gecmis yeni yok", gecmis["yeni"] == [])
    gecmis2 = config.gecmis_karsilastir(["GFE202400000005", "GFE202400000007"])
    kontrol("gecmis yeni", gecmis2["yeni"] == ["GFE202400000007"], f"-> {gecmis2['yeni']}")
    os.remove(config.GECMIS_YOLU)

    print("\n== EXCEL RAPORU ==")
    from report import rapor_olustur
    hedef = os.path.join(YOL, "test_rapor.xlsx")
    gecmis_bilgi = {"kapanan": [], "yeni": ["GFE202400000006"], "onceki_eslesen": 1, "zaman": "01.01.2024 10:00"}
    rapor_olustur(sonuclar, ozet, faturalar, cetvel_sonuc["kayitlar"], hedef, gecmis_bilgi=gecmis_bilgi)
    kontrol("excel olusturuldu", os.path.exists(hedef) and os.path.getsize(hedef) > 0)
    from openpyxl import load_workbook
    wb = load_workbook(hedef)
    kontrol("excel yeni sayfalar", {"KDVDagilimi", "BaFormu", "Grafik"} <= set(wb.sheetnames), f"-> {wb.sheetnames}")
    kontrol("sonuclar tip kolonu", wb["Sonuclar"].cell(row=1, column=6).value == "Tip")
    kontrol("eksik fatura tip kolonu", wb["EksikFaturalar"].cell(row=1, column=3).value == "Tip")
    kontrol("ozet gecmis satiri", any("SON KONTROLE" in str(c.value) for c in wb["Ozet"]["A"]),
            "-> ozet degisim bolumu")

    print("\n== PDF RAPORU ==")
    from report_pdf import rapor_pdf_olustur
    hedef_pdf = os.path.join(YOL, "test_rapor.pdf")
    rapor_pdf_olustur(sonuclar, ozet, faturalar, cetvel_sonuc["kayitlar"], hedef_pdf, gecmis_bilgi=gecmis_bilgi)
    kontrol("pdf olusturuldu", os.path.exists(hedef_pdf) and os.path.getsize(hedef_pdf) > 0)
    from pypdf import PdfReader
    pdf_metin = "\n".join((sayfa.extract_text() or "") for sayfa in PdfReader(hedef_pdf).pages)
    kontrol("pdf sonuclar tip", "Tip" in pdf_metin)
    kontrol("pdf kdv dagilim", "KDV DAĞILIMI" in pdf_metin.replace("İ", "I").upper())
    kontrol("pdf ba formu", "BA FORMU" in pdf_metin.replace("İ", "I").upper())
    kontrol("pdf gecmis degisim", "DEĞİŞİM" in pdf_metin)

    print("\nSONUÇ:", "TÜM TESTLER TAMAM" if BASARILI else "HATALAR VAR")
    sys.exit(0 if BASARILI else 1)
