"""Uygulama sürüm bilgisi."""
import os

SURUM = "2.4.1"
REPO = "ArdaEkiz0/kdv-capraz-kontrol"
YOL = os.path.dirname(os.path.abspath(__file__))
