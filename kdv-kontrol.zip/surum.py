"""Uygulama sürüm bilgisi."""
import os

SURUM = "2.2.2"
REPO = "ArdaEkiz0/kdv-capraz-kontrol"
YOL = os.path.dirname(os.path.abspath(__file__))
