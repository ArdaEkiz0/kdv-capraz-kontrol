"""Uygulama sürüm bilgisi."""
import os

SURUM = "2.3.8"
REPO = "ArdaEkiz0/kdv-capraz-kontrol"
YOL = os.path.dirname(os.path.abspath(__file__))
